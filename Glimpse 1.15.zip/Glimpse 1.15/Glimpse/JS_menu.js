document.addEventListener("DOMContentLoaded", function () {

  // menu lateral
  const menuBtn = document.querySelector(".menu");
  const menuLateral = document.querySelector(".menu-lateral");

  if (menuBtn && menuLateral) {
    menuBtn.addEventListener("click", () => {
      menuLateral.classList.toggle("aberto");
    });
  }

  // suporte
  const botaoSuporte = document.querySelector('.chat-button');
  const janelaSuporte = document.querySelector('.suporte-janela');
  const fecharSuporte = document.querySelector('.fechar-suporte');

  if (botaoSuporte && janelaSuporte) {
    botaoSuporte.addEventListener('click', () => {
      janelaSuporte.classList.toggle('aberta');
    });
  }

  if (fecharSuporte) {
    fecharSuporte.addEventListener('click', () => {
      janelaSuporte.classList.remove('aberta');
    });
  }
});