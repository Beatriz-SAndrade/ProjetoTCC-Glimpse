document.getElementById("enviarsuporte").addEventListener("click", async () => {
    const mensagem = document.getElementById("suporttxt").value;
    const email = localStorage.getItem("email");

    if (!mensagem) {
        alert("Digite uma mensagem antes de enviar!");
        return;
    }

    // conecta com o flask
    try {
        const res = await fetch("http://127.0.0.1:5000/suporte", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email,
                mensagem
            })
        });

        const data = await res.json();

        if (data.sucesso) {
            alert("Mensagem enviada com sucesso");
            document.getElementById("suporttxt").value = "";
        } else {
            alert("Erro ao enviar mensagem");
        }

    } catch (err) {
        console.error(err);
        alert("Erro de conexão com o servidor");
    }
});
