import Bd_conexao as Bd_conexao
from datetime import datetime
import Bd_post as post
import Bd_rede


# função para inserir os comentários no BD
def insert_comentarios(comentario, data, sentimento, link):
    print(" ")
    rep = 0  # contador
    # pega o id do post pelo link
    id_pst = post.read_idPost(link)
    print("ID: ", id_pst)

    conexao = Bd_conexao.get_conexao()
    # loop que percorre os comentários
    while rep < len(comentario):
        print("Comentario: ", comentario[rep])
        # verifica se o comentário já está armazenado no bd
        existe = verifica_comentario(comentario[rep], id_pst)
        print(existe)

        if existe:
            # define um valor numérico para os sentimentos
            if sentimento[rep] == "positivo":
                s = 1.0
            else:
                if sentimento[rep] == "negativo":
                    s = 2.0
                else:
                    s = 0.0

            if conexao:
                print("Conectado com sucesso!")
                cursor = conexao.cursor()

                # Converte data do formato ISO para o do MySQL
                dt = datetime.fromisoformat(data[rep].replace("Z", "+00:00"))
                data_mysql = dt.date()

                print("INSERINDO ", comentario[rep], " - ", data_mysql)
                cursor.execute(
                    "Insert into social_db.comentarios (conteudo,data_comentario,sentimento,id_pst) values (%s,%s,%s,%s)",
                    (comentario[rep], data_mysql, s, id_pst),
                )
                r = conexao.commit()  # confirma a inserção no BD

        else:
            print("JA INSERIDO")
        print("---->")
        print(" ")
        rep += 1

    print("Conexao encerrada")
    conexao.close()
    cursor.close()


# função para verificar se um comentário já existe
def verifica_comentario(conteudo, id_pst):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        cursor = conexao.cursor()
        print("Verificando existencia...")

        cursor.execute(
            "Select 1 from social_db.comentarios where conteudo = %s  && id_pst= %s limit 1;",
            (conteudo, id_pst),
        )
        r = cursor.fetchone()  # pega o primeiro resultado
        print(r)
        conexao.close()
        cursor.close()
        # retorna true se não existir e false se já estiver lá
        if r == None:
            resul = True
        else:
            resul = False

        return resul


# função para retornar o sentimento de um comentário do post
def get_sentimento(id_comentario, id_post):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        cursor.execute(
            "Select sentimento from social_db.comentarios where id_comentario= %s && id_pst= %s",
            (id_comentario, id_post),
        )

        r = cursor.fetchone()
        print(r[0])

        conexao.close()
        cursor.close()
        return r


# função para retornar todos os comentários da rede
def get_comentario():
    conexao = Bd_conexao.get_conexao()
    if conexao:
        cursor = conexao.cursor()
        id_red = Bd_rede.getIdRede()  # pega id da rede social

        cursor.execute(
            """
            SELECT c.conteudo
            FROM comentarios c
            JOIN post p ON c.id_pst = p.id_post
            WHERE p.id_red = %s
        """,
            (id_red,),
        )

        resultados = cursor.fetchall()
        # transforma em lista de strings
        comentarios = [r[0] for r in resultados]

        cursor.close()
        conexao.close()

        return comentarios


# função para retornar os comentários com sentimento
def get_comentarioPorTipo(tipo):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        cursor = conexao.cursor()
        id_red = Bd_rede.getIdRede()  # pega id da rede social

        if tipo == 3:  # todos os comentários
            cursor.execute(
                """
            SELECT c.conteudo
            FROM comentarios c
            JOIN post p ON c.id_pst = p.id_post
            WHERE p.id_red = %s
        """,
                (id_red,),
            )

            resultados = cursor.fetchall()
            comentarios = [r[0] for r in resultados]

        else:  # filtra pelo sentimento
            cursor.execute(
                """
                SELECT c.conteudo
                FROM comentarios c
                JOIN post p ON c.id_pst = p.id_post
                WHERE p.id_red = %s && c.sentimento = %s
            """,
                (
                    id_red,
                    tipo,
                ),
            )

            resultados = cursor.fetchall()

            comentarios = [r[0] for r in resultados]

        cursor.close()
        conexao.close()

        return comentarios


# função para filtrar os comentários por post
def get_comentarioPorFiltro(id_post, tipo):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        cursor = conexao.cursor()
        id_red = Bd_rede.getIdRede()

        if tipo == 3:  # todos os comentários
            cursor.execute(
                """
                SELECT c.conteudo
                FROM comentarios c
                JOIN post p ON c.id_pst = p.id_post
                WHERE p.id_red = %s && c.id_pst = %s
            """,
                (id_red, id_post),
            )

            resultados = cursor.fetchall()

            comentarios = [r[0] for r in resultados]
        else:  # filtra pelo sentimento
            cursor.execute(
                """
                SELECT c.conteudo
                FROM comentarios c
                JOIN post p ON c.id_pst = p.id_post
                WHERE p.id_red = %s && c.sentimento = %s && c.id_pst = %s
            """,
                (id_red, tipo, id_post),
            )

            resultados = cursor.fetchall()
            comentarios = [r[0] for r in resultados]

        cursor.close()
        conexao.close()

        return comentarios

# função para filtrar os sentimentos por post
def get_sentimentos_por_post(id_post):
    conexao = Bd_conexao.get_conexao()
    if not conexao:
        return {"negativo": 0, "neutro": 0, "positivo": 0}

    cursor = conexao.cursor()
    cursor.execute(
        """
        SELECT sentimento, COUNT(*) AS total
        FROM social_db.comentarios
        WHERE id_pst = %s
        GROUP BY sentimento
    """,
        (id_post,),
    )

    r = cursor.fetchall()

    cursor.close()
    conexao.close()

    # retorna 0 neutro, 1 positivo e 2 negativo
    resultado = {"neutro": 0, "positivo": 0, "negativo": 0} 

    for sentimento, total in r:
        if sentimento == 0:
            resultado["neutro"] = total
        elif sentimento == 1:
            resultado["positivo"] = total
        elif sentimento == 2:
            resultado["negativo"] = total

    return resultado


# função para retornar quantos comentários de cada sentimento pelo perfil logado
def get_numeroSentPerfil():
    conexao = Bd_conexao.get_conexao()
    if not conexao:
        return []
    print("Conectado com sucesso!")
    cursor = conexao.cursor()

    id_red = Bd_rede.getIdRede()  # pega o id da rede
    print(id_red)

    cursor.execute(
        "SELECT c.sentimento, COUNT(*) AS total FROM comentarios c JOIN post p ON c.id_pst = p.id_post WHERE p.id_red = %s GROUP BY c.sentimento;",
        (id_red,),
    )
    r = cursor.fetchall()
    conexao.close()
    cursor.close()

    # agrupa por cada sentimento
    resultado = {0: 0, 1: 0, 2: 0}

    for sentimento, total in r:
        resultado[sentimento] = total

    # transforma no formato esperado pelo Flask
    return [(0, resultado[0]), (1, resultado[1]), (2, resultado[2])]


# função para retornar quantos comentários de cada sentimento pelos perfis logados
def get_numeroSentEmpresa(id_red):  # recebe o id como parâmetro
    conexao = Bd_conexao.get_conexao()
    if not conexao:
        return []
    print("Conectado com sucesso!")
    cursor = conexao.cursor()

    cursor.execute(
        """
        SELECT c.sentimento, COUNT(*) AS total
        FROM comentarios c
        JOIN post p ON c.id_pst = p.id_post
        WHERE p.id_red = %s
        GROUP BY c.sentimento
    """,
        (id_red,),
    )

    r = cursor.fetchall()
    conexao.close()
    cursor.close()

    # agrupa por cada sentimento
    resultado = {0: 0, 1: 0, 2: 0}

    for sentimento, total in r:
        resultado[sentimento] = total

    # transforma no formato esperado pelo Flask
    return [(0, resultado[0]), (1, resultado[1]), (2, resultado[2])]
