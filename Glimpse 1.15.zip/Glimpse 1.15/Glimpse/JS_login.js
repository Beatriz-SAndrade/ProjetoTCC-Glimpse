document.getElementById("loginBtn").addEventListener("click", async () => {
  // pega os dados digitados
  const email = document.getElementById("email").value;
  const senha = document.getElementById("senha").value;

  if (!email || !senha) {
    alert("Preencha todos os campos");
    return;
  }

  try {
    // chama o flask
    const response = await fetch("http://127.0.0.1:5000/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      // transforma o objeto em JSON
      body: JSON.stringify({
        email: email,
        senha: senha
      })
    });

    const data = await response.json();

    if (data.sucesso) {
      // guarda o email no LocalStorage
      localStorage.setItem("email", email);
      // redireciona
      window.location.href = "HTML_home.html";
      
    } else {
      alert(data.message);
    }

  } catch (error) {
    alert("Erro ao conectar com o servidor");
    console.error(error);
  }
});

// função para mostrar/esconder senha
function mostrarSenha() {
  const input = document.getElementById("senha");
  input.type = input.type === "password" ? "text" : "password";
}
