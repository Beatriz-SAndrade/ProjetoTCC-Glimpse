document.addEventListener("DOMContentLoaded", async () => {
    // pega o id da empresa no LocalStorage
    const idEmpresa = localStorage.getItem("id_empresa");
    console.log("ID DA EMPRESA:", idEmpresa);
    if (!idEmpresa) {
        console.error("ID da empresa não encontrado");
        return;
    }

    try{
        const response = await fetch(
            `http://127.0.0.1:5000/infosemp?idEmpresa=${idEmpresa}`
        );
        const dados = await response.json();

        if (!dados.sucesso) {
            console.error("Erro ao buscar infos:", dados.message);
            return;
        }

        document.getElementById("empresaNome").innerText = dados.nome;
        document.getElementById("empresaTelefone").innerText =
            dados.telefone || "Não encontrado.";
        document.getElementById("empresaEmail").innerText = dados.email;
        document.getElementById("empresaInstagram").innerText =
            dados.instagram || "@não encontrado";

    } catch (erro) {
        console.error("Erro geral:", erro);
    }

    // pega o canvas do html onde terá o gráfico
    const ctx = document.getElementById('graficoFeed');
    if (!ctx) {
        console.error("Canvas não encontrado");
        return;
    }

    // cria o gráfico de pizza
    const chart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Negativas', 'Neutras', 'Positivas'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: ['#b71c1c', '#fbc02d', '#388e3c']
            }]
        }
    });

    // resposta do flask com os dados do BD
    fetch(`http://localhost:5000/sentimentosemp/${idEmpresa}`)
        .then(res => res.json())
        .then(dados => {
            console.log("Dados recebidos:", dados);
            chart.data.datasets[0].data = [
                dados.negativo,
                dados.neutro,
                dados.positivo
            ];
            // atualiza o gráfico
            chart.update();
        })
        .catch(err => console.error("Erro no gráfico:", err));
});
