// aguarda o carregamento completo do HTML antes de executar o script
document.addEventListener("DOMContentLoaded", async () => {
    // recupera o email do usuário armazenado no localStorage
    const email = localStorage.getItem("email");
    // faz a requisição ao backend para listar as empresas associadas ao usuário
    const response = await fetch(
        `http://127.0.0.1:5000/listarempresas?email=${email}`
    );
    // converte a resposta para JSON
    const data = await response.json();

    if (!data.sucesso) {
        console.error("Erro ao listar empresas");
        return;
    }

    // lista empresas
    const empresas = data.empresas;
    // container onde os cards das empresas serão inseridos
    const container = document.getElementById("lista-empresas");

    // cria um card para cada empresa
    empresas.forEach(emp => {
        const card = document.createElement("div");
        card.classList.add("card");

        const foto = emp.id_empresa && emp.img_empresa !== "" && emp.img_empresa !== null
        ? emp.img_empresa
        : "icone-perfil.png"; // fallback caso não tenha foto

        card.innerHTML = `
      <div class="card-empresa">
        <img src="${foto}" class="card-empresa">
      </div>
      <h3>${emp.nome}</h3>
    `;
        // guarda o nome original em lowercase
        card.dataset.nomeOriginal = emp.nome.toLowerCase();

        console.log("EMP:", emp);
        // adiciona evento de clique no card
        card.addEventListener("click", () => {
            // armazena o id do usuário no localStorage
            localStorage.setItem("id_empresa", emp.id_empresa);
            // redireciona
            window.location.href = "HTML_grafico_empresa.html";
        });
        // insere o card no container
        container.appendChild(card);
    });
});

//BARRA DE PESQUISA
const barraPesquisa = document.getElementById("barra-pesquisa");

barraPesquisa.addEventListener("input", () => {
  const termo = barraPesquisa.value.toLowerCase();
  const cards = document.querySelectorAll(".card");

  cards.forEach(card => {
    const nomeOriginal = card.dataset.nomeOriginal;

    if (!nomeOriginal) return;

    if (termo === "") {
      card.style.display = "block";
      return;
    }

    if (nomeOriginal.includes(termo)) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
  });
});


