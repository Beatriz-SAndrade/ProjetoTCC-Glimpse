window.addEventListener("DOMContentLoaded", async () => {
    alert("Bem-vindo!");
    // pega o email logado do LocalStorage
    const email = localStorage.getItem("email");

    try {
        console.log("EMAIL DO USUÁRIO:", email);
        if (!email) {
            alert("Usuário não logado");
            window.location.href = "HTML_login.html";
        }
        // conecta com o BD pelo flask
        const response = await fetch(`http://127.0.0.1:5000/infos?email=${email}`);
        const dados = await response.json();

        if (!dados.sucesso) {
            console.error("Erro ao buscar infos:", dados.message);
            return;
        }

        // preenche os dados na tela
        document.getElementById("nome-user").innerText = dados.nome;
        document.getElementById("nome-companhia").innerText = dados.nome;
        document.getElementById("telefone").innerText = dados.telefone || "Preencha este campo.";
        document.getElementById("email").innerText = dados.email;
        document.getElementById("instagram").innerText = dados.instagram;

        // infos fakes
        const tiktok = localStorage.getItem(`tiktok_${email}`);
        const twitter = localStorage.getItem(`twitter_${email}`);
        const youtube = localStorage.getItem(`youtube_${email}`);

        document.getElementById("tiktok").innerText =
            tiktok || "Preencha este campo.";

        document.getElementById("twitter").innerText =
            twitter || "Preencha este campo.";

        document.getElementById("youtube").innerText =
            youtube || "Preencha este campo.";

        // inputs (formulário)
        const inputNome = document.getElementById("input-nome");
        inputNome.value = dados.nome;
        inputNome.defaultValue = dados.nome;

        const inputTelefone = document.getElementById("input-telefone");
        inputTelefone.value = dados.telefone || "";
        inputTelefone.defaultValue = dados.telefone || "";

        if(dados.foto && dados.foto !== "" && dados.foto !== null){
        fotoPreview.src = dados.foto;
        }

    } catch (erro) {
        console.error("Erro geral:", erro);
    }
});

// abrir formulario
function mostrarFormulario() {
    document.getElementById("visualizacao-dados").style.display = "none";
    document.getElementById("form-alterar").classList.remove("oculto");
    ativarEdicaoFoto();
}


// salvar alterações
async function salvarAlteracoes(event) {
    event.preventDefault();

    if (!houveAlteracao()) {
        document.getElementById("form-alterar").classList.add("oculto");
        document.getElementById("visualizacao-dados").style.display = "flex";

        enviarFoto(); 
        desativarEdicaoFoto();
        alert("Nenhuma alteração foi feita");

        return;
    }

    enviarFoto();

    const email = localStorage.getItem("email");

    // dados reais
    const inputNome = document.getElementById("input-nome");
    const inputTelefone = document.getElementById("input-telefone");

    const nome = inputNome.value;
    const telefone = inputTelefone.value;
    // dados fake
    const tiktok = document.getElementById("input-tiktok").value;
    const twitter = document.getElementById("input-twitter").value;
    const youtube = document.getElementById("input-youtube").value;

    // salva os dados fakes no LocalStorage
    localStorage.setItem(`tiktok_${email}`, tiktok);
    localStorage.setItem(`twitter_${email}`, twitter);
    localStorage.setItem(`youtube_${email}`, youtube);

    // atualiza as informações verdadeiras no BD
    if (nome !== inputNome.defaultValue ||
        telefone !== inputTelefone.defaultValue) {
        try {
            const response = await fetch("http://127.0.0.1:5000/atualizar_empresa", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    email,
                    nome,
                    telefone
                })
            });

            const dados = await response.json();

            if (!dados.sucesso) {
                alert("Erro ao salvar dados");
                desativarEdicaoFoto();
                return;
            }
            inputNome.defaultValue = nome;
            inputTelefone.defaultValue = telefone;

        } catch (erro) {
            console.error("Erro ao salvar:", erro);
            alert("Erro de conexão com o servidor");
        }
    }
    // atualiza só na tela
    document.getElementById("nome-user").innerText = nome;
    document.getElementById("nome-companhia").innerText = nome;
    document.getElementById("telefone").innerText = telefone || "Preencha este campo.";
    document.getElementById("tiktok").innerText = tiktok || "Preencha este campo.";
    document.getElementById("twitter").innerText = twitter || "Preencha este campo.";
    document.getElementById("youtube").innerText = youtube || "Preencha este campo.";

    // volta pra visualização
    document.getElementById("form-alterar").classList.add("oculto");
    document.getElementById("visualizacao-dados").style.display = "flex";
    desativarEdicaoFoto();
    alert("Dados atualizados com sucesso!");
}

// função que detecta alterações
function houveAlteracao() {
    const inputs = document.querySelectorAll("#form-alterar input");

    for (let input of inputs) {
        if (input.value !== input.defaultValue) {
            return true;
        }
    }
    return false;
}

const foto = document.getElementById("fotoPreview");
const inputFoto = document.getElementById("inputFoto");
const wrapperFoto = document.querySelector(".foto-wrapper");

function ativarEdicaoFoto() {
  wrapperFoto.classList.add("editavel");
}

function desativarEdicaoFoto() {
  wrapperFoto.classList.remove("editavel");
}

if (foto && inputFoto) {
  foto.addEventListener("click", () => {
    if (wrapperFoto.classList.contains("editavel")) {
      inputFoto.click();
    }
  });
 
  inputFoto.addEventListener("change", () => {
    const file = inputFoto.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      foto.src = reader.result;
      localStorage.setItem("fotoPerfil", reader.result);
    };
    reader.readAsDataURL(file);
  });

}


const inputFt = document.getElementById("inputFoto");
const fotoPreview = document.getElementById("fotoPreview");
const email = localStorage.getItem("email");

async function enviarFoto() {
  const arquivo = inputFt.files[0];

  if (!arquivo) {
    console.log("SEM FOTO")
    return;
  }

  const formData = new FormData();
  formData.append("foto", arquivo);
  formData.append("email", email);

  const resposta = await fetch("http://127.0.0.1:5000/upload-foto", {
    method: "POST",
    body: formData
  });

  const dados = await resposta.json();
  console.log(dados.link);

  fotoPreview.src = dados.link + "?t=" + new Date().getTime();
}