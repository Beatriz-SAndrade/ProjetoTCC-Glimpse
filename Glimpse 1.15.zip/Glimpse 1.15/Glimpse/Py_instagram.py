from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.remote.webelement import WebElement
from webdriver_manager.chrome import ChromeDriverManager
import Bd_post
import Bd_comentarios
import requests
import json
import sys
import io
import re
import time
import random

# cria a variável driver
driver = None

# configurações da api da IA
API_KEY = "-"

# carrega emojis e outros caracteres incomuns
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


# função que cria o driver
def criar_driver():
    # inicializa o navegador
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-infobars")
    options.add_argument("--start-maximized")
    options.add_argument(
        "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"
    )
    # oculta a janela do navegador
    # options.add_argument("--headless")

    # cria o service com o caminho
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=options)
    return driver


# função para classificar o sentimento de cada comentário
def analisar_sentimento(textos):
    url = "https://openrouter.ai/api/v1/chat/completions"  # caminho da IA
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    items = [{"id": idx, "texto": textos[idx]} for idx in range(len(textos))]

    # prompt enviado para a IA
    prompt = {
        "tarefa": "Classifique o sentimento de CADA comentário listado abaixo.",
        "regras": [
            "Você deve retornar UM resultado para CADA comentário.",
            "Use apenas: 'positivo', 'negativo' ou 'neutro'.",
            "Em caso de dúvida real, classifique como 'neutro'.",
        ],
        "definições": {
            "Considere um comentário positivo": "elogios, apoio, admiração, gratidão, humor, carinho ou emojis como ❤️ 😍 👏 🙌 🙏 🥹 🤩 😂 😏 🥵 🫦",
            "Considere um comentário negativo": "insultos, ataques, ódio, ironia agressiva, zombaria, emojis como 🤢 ☠️ 💀",
            "Considere um comentário neutro": "perguntas, comentários informativos",
        },
        "observações": [
            "Comentários compostos apenas por emojis positivos, como ❤️ 😍 👏 🫶 ✨ ❤️‍🔥 🤣 😂 🥰 🤩 🫦, devem ser classificados como POSITIVO.",
            "Emojis como 😭 😩 😫 🥺 🥹 podem indicar emoção POSITIVA quando acompanhados de elogios.",
            "Comentários curtos como 'lindo', 'fofos', 'amei', 'perfeito' devem ser classificados como POSITIVO.",
        ],
        "formato_de_resposta": "Retorne uma LISTA de objetos JSON no formato {id, sentimento}.",
        "dados": items,
    }

    # configurações do modelo
    data = {
        "model": "mistralai/mistral-nemo",
        "response_format": {"type": "json_object"},
        "messages": [
            {
                "role": "system",
                "content": "Você é um classificador de sentimentos extremamente preciso.",
            },
            {"role": "user", "content": json.dumps(prompt, ensure_ascii=False)},
        ],
    }

    # loop para evitar erro 429
    while True:
        response = requests.post(url, headers=headers, json=data)

        if response.status_code == 200:
            resposta_texto = response.json()["choices"][0]["message"]["content"]

            try:
                resposta_json = json.loads(resposta_texto)
            except Exception as e:
                print("Falha ao converter resposta em JSON:", resposta_texto)
                return ["neutro"] * len(textos)

            # extrai sentimentos respeitando a ordem
            sentimentos = ["neutro"] * len(textos)

            if isinstance(resposta_json, list):
                lista = resposta_json
            elif isinstance(resposta_json, dict):
                lista = (
                    resposta_json.get("resultados") or resposta_json.get("dados") or []
                )
            else:
                print("Formato inesperado:", resposta_json)
                return ["neutro"] * len(textos)

            # monta lista final
            sentimentos = ["neutro"] * len(textos)
            for item in lista:
                idx = item.get("id")
                sent = item.get("sentimento", "neutro").lower()
                if idx is not None and 0 <= idx < len(sentimentos):
                    sentimentos[idx] = sent

            return sentimentos

        elif response.status_code == 429:
            print("Rate limit — esperando 5 segundos...")
            time.sleep(5)
        else:
            print("Erro inesperado:", response.text)
            return ["erro"] * len(textos)


# função para dividir a lista em lotes de 'tam' comentários no máximo
def dividir_lotes(lista, tam):
    for i in range(0, len(lista), tam):
        yield lista[i : i + tam]


# função para verificar se o link aberto é válido
def verificar_url(url):
    photo = r"^https://www.instagram.com/[^/]+/p/[A-Za-z0-9_-]+/$"
    reel = r"^https://www.instagram.com/[^/]+/reel/[A-Za-z0-9_-]+/$"
    if bool(re.match(photo, url)):
        return re.match(photo, url)
    else:
        return bool(re.match(reel, url))


# função para coletar a data dos posts
def pegar_datapost(classname, driver):
    try:
        elemento = driver.find_element(By.CLASS_NAME, classname)
        data = elemento.get_attribute("datetime")
        return data
    except Exception as e:
        print(f"Não foi possível pegar a data do post: {e}")
        return None


# função para coletar a data dos comentários
def pegar_datacoment(datas, driver):
    try:
        elementos = driver.find_elements(By.TAG_NAME, "time")
        for e in elementos:
            datas.append(e.get_attribute("datetime"))
    except Exception as ex:
        print(f"Não foi possível pegar a data do comentário: {ex}")
        return None


# executa o scraping após ser requisitado
def executar_scraping(instagram_user, modo):
    print(f"Iniciando scraping {modo} do perfil: {instagram_user}\n")

    # início do bot
    try:
        driver = criar_driver()

        # abre o instagram
        driver.get("https://www.instagram.com/accounts/login/")
        time.sleep(random.uniform(6.5, 8.5))

        # faz login
        username_input = driver.find_element(By.NAME, "username")
        password_input = driver.find_element(By.NAME, "password")
        username_input.send_keys("seu-usaer")
        password_input.send_keys("sua-senha")
        password_input.send_keys(Keys.ENTER)

        # espera logar
        time.sleep(random.uniform(15, 20))

        # abre o perfil
        driver.get(f"https://www.instagram.com/{instagram_user}/")
        time.sleep(random.uniform(6, 8))

        # pega todos os links dos posts carregados
        post_elements = driver.find_elements(By.TAG_NAME, "a")
        post_links = {
            el.get_attribute("href")
            for el in post_elements
            if el.get_attribute("href")
            and (
                "/p/" in el.get_attribute("href")
                or "/reel/" in el.get_attribute("href")
            )
        }
        post_links = list(post_links)
        print(f"Total de posts encontrados: {len(post_links)}")

        if modo == "completo":
            # desce a página para carregar mais posts
            for i in range(1, 8):
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(random.uniform(1.5, 4))
                novos_posts = driver.find_elements(By.TAG_NAME, "a")
                novos_links = {
                    el.get_attribute("href")
                    for el in novos_posts
                    if el.get_attribute("href")
                    and (
                        "/p/" in el.get_attribute("href")
                        or "/reel/" in el.get_attribute("href")
                    )
                }
                post_links.extend(novos_links)
        else:
            # desce um pouco a página para carregar mais posts
            for i in range(1, 2):
                driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(random.uniform(1.5, 4))
                novos_posts = driver.find_elements(By.TAG_NAME, "a")
                novos_links = {
                    el.get_attribute("href")
                    for el in novos_posts
                    if el.get_attribute("href")
                    and (
                        "/p/" in el.get_attribute("href")
                        or "/reel/" in el.get_attribute("href")
                    )
                }
                post_links.extend(novos_links)

        # loop pelos posts
        for link in post_links:
            # vetor que irá armazenar os comentários
            comentarios = []

            if verificar_url(link):
                print(link)
                # abre o post
                driver.get(link)
                time.sleep(random.uniform(4.5, 6))
                # pega a data do post
                data = pegar_datapost("x1p4m5qa", driver=driver)
                print(f"Data do post: {data}\n")

                # insere informações do post no BD
                Bd_post.insert_post(link, data)

                # carrega mais comentarios
                botaoCarregar = driver.find_elements(By.CLASS_NAME, "xw2csxc")
                for i in range(1, 6):
                    if botaoCarregar:
                        try:
                            driver.execute_script(
                                "arguments[0].scrollIntoView(true);", botaoCarregar[-1]
                            )
                            time.sleep(random.uniform(1, 2.5))
                            botaoCarregar[-1].send_keys(Keys.END)
                            time.sleep(random.uniform(2, 3.5))
                        except Exception as e:
                            print("")
                    else:
                        print("N tem mais")
                        break

                # captura as datas dos comentários
                datas = []
                pegar_datacoment(datas, driver=driver)
                # deleta os índices desnecessários para que fique armazenado apenas a data dos comentários
                del datas[0]
                del datas[-1]

                # captura os comentários
                comentarios_raw = driver.find_elements(By.CLASS_NAME, "x1lliihq")

                print("--- COMENTÁRIOS ENCONTRADOS ---\n")
                for idx, c in enumerate(comentarios_raw):
                    # filtra os comentários válidos
                    if isinstance(c, WebElement):
                        texto = c.text.strip()
                        html = c.get_attribute("innerHTML")
                        if texto:
                            if (
                                "<" not in html
                                and "curtida" not in html
                                and "curtidas" not in html
                                and "Ver tradução" not in html
                                and "Responder" not in html
                                and "Ver todas" not in html
                                and "Meta" not in html
                                and "Sobre" not in html
                                and "Blog" not in html
                                and "Carreiras" not in html
                                and "Ajuda" not in html
                                and "API" not in html
                                and "Privacidade" not in html
                                and "Termos" not in html
                                and "Localizações" not in html
                                and "Instagram Lite" not in html
                                and "Threads" not in html
                                and "Upload de contatos e não usuários" not in html
                                and "Português (Brasil)" not in html
                                and "Página inicial" not in html
                                and "Pesquisa" not in html
                                and "Explorar" not in html
                                and "Reels" not in html
                                and "Mensagens" not in html
                                and "Notificações" not in html
                                and "Criar" not in html
                                and "Painel" not in html
                                and "Perfil" not in html
                                and "Mais" not in html
                                and "Ver comentários ocultos" not in html
                                and "Esses comentários foram ocultos porque podem ser enganosos, ofensivos ou spam. As pessoas ainda podem tocar na tela para vê-los."
                                not in html
                            ):
                                # adiciona os comentários no vetor para enviar para a análise de sentimentos
                                comentarios.append(texto)

                for com in comentarios:
                    print(f"Comentário: {com}\n")  # lista de comentários

                # garante que a lista de datas tenha o mesmo tamanho da lista de comentários
                datas = datas[: len(comentarios)]

                for dat in datas:
                    print(f"Data: {dat}\n")  # lista de datas dos comentários

                sentimentos = []
                # divide os comentários em lotes para enviar para a IA
                for lote in dividir_lotes(comentarios, 50):
                    # analisa o sentimento de cada comentário
                    resposta = analisar_sentimento(lote)
                    sentimentos.extend(resposta)
                    time.sleep(1.5)

                for sen in sentimentos:
                    print(
                        f"Sentimento: {sen}\n"
                    )  # lista de sentimentos dos comentários

            # insere informações dos comentários no BD
            Bd_comentarios.insert_comentarios(comentarios, datas, sentimentos, link)

        print("Scraping finalizado com sucesso")
    except Exception as ex:
        print(f"Scraping quebrou: {ex}")

    # garante que o driver encerre
    finally:
        try:
            driver.quit()
            print("Driver encerrado")
        except:
            pass
