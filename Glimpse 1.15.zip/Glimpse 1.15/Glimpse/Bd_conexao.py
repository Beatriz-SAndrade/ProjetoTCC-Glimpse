import pymysql
from datetime import datetime

# função para conectar com o banco de dados
def get_conexao():
    #mudar caminho para seu BD!!!
    return pymysql.connect(
        host="127.0.0.1",
        port=3306,
        user="-",  
        password="-",  
        database="social_db",
    )
