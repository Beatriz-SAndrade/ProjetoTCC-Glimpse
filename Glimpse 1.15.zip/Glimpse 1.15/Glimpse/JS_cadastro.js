// seleciona o formulário de cadastro pelo ID
const form = document.getElementById('cadastroForm');

// adiciona um evento para quando o formulário for enviado
form.addEventListener('submit', function (event) {
  event.preventDefault(); // não recarrega a página

  // captura os valores digitados pelo usuário nos campos do formulário
  const nome = document.getElementById('nome').value;
  const email = document.getElementById('email').value;
  const senha = document.getElementById('senha').value;
  const instagram = document.getElementById('instagram').value;

  if (nome === "" || email === "" || senha === "") {
    alert("Preencha todos os campos obrigatórios!");
    return;
  }

  // envia os dados do cadastro para o backend 
  fetch("http://localhost:5000/cadastro", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    // converte os dados do usuário para JSON
    body: JSON.stringify({
      nome: nome,
      email: email,
      senha: senha,
      instagram: instagram
    })
  })

    // converte a resposta do backend para JSON
    .then(res => res.json())
    .then(data => {
      if (data.sucesso) {
        // armazena o email do usuário no localStorage para manter a sessão ativa
        localStorage.setItem("email", email);
        // redireciona
        window.location.href = "HTML_home.html";
      } else {
        alert(data.message);
      }

    })
    .catch(err => {
      console.error(err);
      alert("Erro ao cadastrar");
    });
});

