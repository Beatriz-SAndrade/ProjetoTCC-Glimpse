import Bd_conexao as Bd_conexao
import pymysql


# função para buscar uma empresa a partir do email
def buscar_por_email(email):
    conexao = Bd_conexao.get_conexao()
    cursor = conexao.cursor(pymysql.cursors.DictCursor)  # retorno como dicionário

    cursor.execute("SELECT * FROM social_db.empresa WHERE email = %s", (email,))

    usuario = cursor.fetchone()
    cursor.close()
    conexao.close()

    return usuario


# função para verificar se o email já está cadastrado
def verifica_existencia(email):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        cursor = conexao.cursor()

        print("Verificando existencia...")
        cursor.execute(
            "Select 1 from social_db.empresa where email = %s limit 1;", (email)
        )
        r = cursor.fetchone()
        conexao.close()
        cursor.close()

        # retorna true se não existe e false se existe
        if r == None:
            resul = True
        else:
            resul = False

        return resul


# função para inserir empresa no BD
def inserir_empresa(email, senha, nome):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        # verifica se o email existe
        if verifica_existencia(email):
            print("INSERINDO ", email, senha, nome)
            cursor.execute(
                "Insert into social_db.empresa (email,senha,nome) values (%s,%s,%s)",
                (email, senha, nome),
            )

            r = conexao.commit()
            conexao.close()
            cursor.close()
            return True
        else:
            # se o email existir no BD, cancela
            conexao.close()
            cursor.close()
            return False


# função para retornar o id da empresa a partir do email
def get_idEmpresa(email):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        cursor.execute(
            "Select id_empresa from social_db.empresa where email= %s", (email)
        )

        r = cursor.fetchone()
        conexao.close()
        cursor.close()

        return r


# função para retornar o id da empresa a partir do email
def get_Byid(id):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        cursor.execute(
            "Select email, nome, telefone from social_db.empresa where id_empresa= %s",
            (id),
        )

        r = cursor.fetchone()
        conexao.close()
        cursor.close()

        if r:
            return {"email": r[0], "nome": r[1], "telefone": r[2]}
        return None


# função para carregar os dados da empresa
def get_dados(email):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor(pymysql.cursors.DictCursor)  # retorno como dicionário

        cursor.execute(
            "Select email, nome, telefone from social_db.empresa where email= %s",
            (email,),
        )

        r = cursor.fetchone()
        conexao.close()
        cursor.close()
        # retorna email, nome e telefone da empresa
        return r


# função para atualizar o perfil da empresa
def atualizar_dados_empresa(email, nome, telefone):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()
        # atualiza nome e o telefone a partir do email
        sql = """
        UPDATE social_db.empresa
        SET nome = %s, telefone = %s
        WHERE email = %s
        """

        cursor.execute(sql, (nome, telefone, email))
        conexao.commit()
        linhas_afetadas = cursor.rowcount

        conexao.close()
        cursor.close()

        return (
            linhas_afetadas > 0
        )  # retorna true se a atualização funcionou e false se não


# função para mudar a foto da empresa
def atualizar_foto(img_empresa, email):
    conexao = Bd_conexao.get_conexao()

    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        sql = """
        UPDATE social_db.empresa
        SET img_empresa = %s
        WHERE email = %s
        """

        cursor.execute(sql, (img_empresa, email))
        conexao.commit()

        conexao.close()
        cursor.close()


# função para retornar a foto de perfil
def getfoto(email):
    conexao = Bd_conexao.get_conexao()
    cursor = conexao.cursor(pymysql.cursors.DictCursor)

    cursor.execute(
        "SELECT img_empresa FROM social_db.empresa WHERE email = %s", (email,)
    )

    img = cursor.fetchone()
    cursor.close()
    conexao.close()

    return img["img_empresa"]


# função para listar todas as empresas menos a logada no momento
def listar_empresas(email):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor(pymysql.cursors.DictCursor)  # retorno como dicionário

        cursor.execute(
            """
        SELECT id_empresa, nome, img_empresa
        FROM empresa
        WHERE email != %s
    """,
            (email,),
        )

    empresas = cursor.fetchall()
    conexao.close()
    cursor.close()
    return empresas
