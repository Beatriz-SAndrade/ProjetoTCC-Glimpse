import Bd_conexao
import Bd_empresa
import pymysql

id_rede = 0 #guarda o id da rede social logada

# função para buscar o nome do perfil do Instagram usando o email
def buscar_perfil_por_email(email):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        cursor = conexao.cursor(pymysql.cursors.DictCursor)  # retorno como dicionário

        print("Verificando existencia...")
        cursor.execute(
            "SELECT nome_usuario FROM social_db.rede_social WHERE email_rede = %s",
            (email),
        )

        resultado = cursor.fetchone()
        conexao.close()
        cursor.close()

        if resultado:
            return resultado["nome_usuario"]
        else:
            return None

# função para inserir a rede soocial no BD
def inserir_Rede(nome_usuario, email):
    conexao = Bd_conexao.get_conexao()
    id_emp = Bd_empresa.get_idEmpresa(email) #busca o id da empresa

    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        print("INSERINDO ", nome_usuario, id_emp, email)
        cursor.execute(
            "Insert into social_db.rede_social (nome_usuario,id_emp,email_rede) values (%s,%s,%s)",
            (nome_usuario, id_emp, email),
        )
        r = conexao.commit()

        conexao.close()
        cursor.close()

# função para buscar o id da rede pelo nome do usuário
def get_idRede(Nome_usuario):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        cursor.execute(
            "Select id_rede from social_db.rede_social where nome_usuario= %s",
            (Nome_usuario),
        )
        r = cursor.fetchone()

        conexao.close()
        cursor.close()

        return r

# função para buscar o id da rede pelo email do usuário
def get_idRedeByEmail(email_rede):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        cursor.execute(
            "Select id_rede from social_db.rede_social where email_rede= %s",
            (email_rede),
        )
        r = cursor.fetchone()

        conexao.close()
        cursor.close()

        return r

# função para retornar o id pra consultas futuras
def getIdRede():
    global id_rede
    return id_rede

# função para salvar o id da rede após o login
def setIdRede(idr):
    global id_rede
    id_rede = idr
