from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from email.message import EmailMessage
from werkzeug.utils import secure_filename
from Bd_post import get_linksPostByIdRede, read_idPost
from threading import Thread
from Py_instagram import executar_scraping
from Bd_comentarios import (
    get_numeroSentPerfil,
    get_comentarioPorTipo,
    get_comentarioPorFiltro,
    get_numeroSentEmpresa,
    get_sentimentos_por_post,
)
import Bd_rede
import Bd_empresa
import smtplib
import os
import hashlib
import cloudinary
import cloudinary.uploader
import cloudinary.api

# mudar configurações da api!!!
cloudinary.config(
    cloud_name="-",
    api_key="-",
    api_secret="-",
)

# configura a api do flask
app = Flask(__name__)
CORS(app)
# impede dois scrapings ao mesmo tempo
scraping_em_execucao = False


# função para executar o scraping fora da thread
def scraping_background(instagram, modo):
    global scraping_em_execucao

    try:
        executar_scraping(instagram, modo=modo)
    except Exception as e:
        print("Erro no scraping em background:", e)
    finally:
        scraping_em_execucao = False


# função para coletar a quantidade de comentários por sentimento
@app.route("/sentimentos")
def sentimentos():
    r = get_numeroSentPerfil()

    dados = {"neutro": 0, "positivo": 0, "negativo": 0}
    for sentimento, total in r:
        if sentimento == 0:
            dados["neutro"] = total
        elif sentimento == 1:
            dados["positivo"] = total
        elif sentimento == 2:
            dados["negativo"] = total

    return jsonify(dados)


# função para coletar as estatísticas de sentimento das outras empresas
@app.route("/sentimentosemp/<int:id_red>")
def sentimentos_empresa(id_red):
    r = get_numeroSentEmpresa(id_red)

    dados = {"neutro": 0, "positivo": 0, "negativo": 0}
    for sentimento, total in r:
        if sentimento == 0:
            dados["neutro"] = total
        elif sentimento == 1:
            dados["positivo"] = total
        elif sentimento == 2:
            dados["negativo"] = total

    return jsonify(dados)


# função para coletar as estatísticas de sentimento de cada post
@app.route("/sentimentospost/<int:id_post>")
def sentimentos_por_post(id_post):
    dados = get_sentimentos_por_post(id_post)
    return jsonify(dados)


# função para disparar o scraping do perfil todo
@app.route("/scrapingcompleto", methods=["POST"])
def scraping_completo():
    global scraping_em_execucao

    if scraping_em_execucao:
        return (
            jsonify(
                {
                    "sucesso": False,
                    "message": "Scraping já está em execução. Aguarde finalizar.",
                }
            ),
            409,
        )

    dados = request.json
    email = dados.get("email")
    # busca perfil do instagram da conta logada
    instagram = Bd_rede.buscar_perfil_por_email(email)

    scraping_em_execucao = True

    # inicia o scraping
    Thread(
        target=scraping_background, args=(instagram, "completo"), daemon=True
    ).start()

    return (
        jsonify(
            {
                "sucesso": True,
                "message": "Scraping completo iniciado. (isso pode levar algum tempo...)",
            }
        ),
        200,
    )


# função para disparar o scraping do início do perfil
@app.route("/scrapingleve", methods=["POST"])
def scraping_leve():
    global scraping_em_execucao
    if scraping_em_execucao:
        return (
            jsonify(
                {
                    "sucesso": False,
                    "message": "Scraping já está em execução. Aguarde finalizar.",
                }
            ),
            409,
        )
    dados = request.json
    email = dados.get("email")
    # busca perfil do instagram da conta logada
    instagram = Bd_rede.buscar_perfil_por_email(email)

    scraping_em_execucao = True

    # inicia o scraping
    Thread(target=scraping_background, args=(instagram, "leve"), daemon=True).start()

    return (
        jsonify(
            {
                "sucesso": True,
                "message": "Scraping leve iniciado. (isso pode levar algum tempo...)",
            }
        ),
        200,
    )


# função para realizar o cadastro da conta
@app.route("/cadastro", methods=["POST"])
def cadastro():
    # recebe os dados do front
    dados = request.json
    email = dados.get("email")
    senha = dados["senha"]
    nome = dados.get("nome")
    instagram = dados.get("instagram")
    # criptografa a senha
    senha_hash = generate_password_hash(senha)

    if not nome or not email or not senha or not instagram:
        return (jsonify({"sucesso": False, "message": "Campos obrigatórios faltando"}),)

    # insere as informações da empresa no BD
    if Bd_empresa.inserir_empresa(email, senha_hash, nome) == True:
        Bd_rede.inserir_Rede(instagram, email)
        return (
            jsonify(
                {
                    "sucesso": True,
                    "message": "Cadastro realizado com sucesso!",
                }
            ),
            201,
        )
    else:
        return jsonify({"sucesso": False}), 400


# função para realizar o login da conta
@app.route("/login", methods=["POST"])
def login():
    dados = request.json
    email = dados["email"]
    senha = dados["senha"]

    # busca empresa pelo email
    usuario = Bd_empresa.buscar_por_email(email)

    if usuario is None:
        return jsonify({"sucesso": False, "message": "Email incorreto"}), 401

    # verifica hash da senha
    senha_hash = usuario["senha"]

    if check_password_hash(senha_hash, senha):

        print(email)
        # salva o id da rede
        id_rede = Bd_rede.get_idRedeByEmail(email)
        Bd_rede.setIdRede(id_rede[0])
        print("ID_REDE: ", Bd_rede.getIdRede())

        return jsonify({"sucesso": True, "message": "Login realizado com sucesso"}), 200
    else:
        return jsonify({"sucesso": False, "message": "Senha incorreta"}), 401


# função para retornar comentários filtrados por sentimento
@app.route("/pegaComentarioPorTipo", methods=["GET"])
def pegaComentarioPorTipo():
    try:
        tipo = request.args.get("tipo", "").lower()

        if tipo == "positivos":
            comentarios = get_comentarioPorTipo(1.0)
        elif tipo == "negativos":
            comentarios = get_comentarioPorTipo(2.0)
        elif tipo == "neutros":
            comentarios = get_comentarioPorTipo(0.0)
        else:
            comentarios = get_comentarioPorTipo(3.0)

        return jsonify(comentarios)

    except Exception as e:
        return jsonify({"sucesso": False, "message": str(e)}), 500


# função para retornar comentários filtrados por sentimento e por post
@app.route("/pegaComentarioPorFiltro", methods=["GET"])
def pegaComentarioPorFiltro():
    try:
        tipo = request.args.get("tipo", "").lower()
        id_post = request.args.get("id_post", type=int)

        if tipo == "positivos":
            comentarios = get_comentarioPorFiltro(id_post, 1.0)
        elif tipo == "negativos":
            comentarios = get_comentarioPorFiltro(id_post, 2.0)
        elif tipo == "neutros":
            comentarios = get_comentarioPorFiltro(id_post, 0.0)
        else:
            comentarios = get_comentarioPorFiltro(id_post, 3.0)

        return jsonify(comentarios)

    except Exception as e:
        return jsonify({"sucesso": False, "message": str(e)}), 500


# função para coletar links e o id dos posts
@app.route("/pegaLinks", methods=["GET"])
def pegaLinks():
    try:
        links = get_linksPostByIdRede()  # consulta link
        posts = []

        for link in links:
            # consulta id do post
            id_post = read_idPost(link)
            posts.append({"id_post": id_post, "link": link})

        return jsonify(posts)

    except Exception as e:
        return jsonify({"sucesso": False, "message": str(e)}), 500


# função para retornar dados do perfil da empresa selecionada
@app.route("/infos", methods=["GET"])
def pegarInfos():
    try:
        email = request.args.get("email")
        empresa = Bd_empresa.get_dados(email)
        instagram = Bd_rede.buscar_perfil_por_email(email)
        foto = Bd_empresa.getfoto(email)

        print("LINK FOTO: ", foto)

        if not empresa:
            return jsonify({"sucesso": False}), 404

        return jsonify(
            {
                "sucesso": True,
                "email": empresa["email"],
                "nome": empresa["nome"],
                "telefone": empresa["telefone"],
                "instagram": instagram,
                "foto": foto,
            }
        )
    except Exception as e:
        return jsonify({"sucesso": False, "message": str(e)}), 500


# função para retornar dados do perfil da empresa selecionada
@app.route("/infosemp", methods=["GET"])
def pegarInfosEmp():
    try:
        idEmp = request.args.get("idEmpresa")  # pega o id enviado
        empresa = Bd_empresa.get_Byid(idEmp)
        instagram = Bd_rede.buscar_perfil_por_email(empresa["email"])

        if not empresa:
            return jsonify({"sucesso": False}), 404

        return jsonify(
            {
                "sucesso": True,
                "email": empresa["email"],
                "nome": empresa["nome"],
                "telefone": empresa["telefone"],
                "instagram": instagram,
            }
        )
    except Exception as e:
        return jsonify({"sucesso": False, "message": str(e)}), 500


# função para atualizar os dados da empresa
@app.route("/atualizar_empresa", methods=["PUT"])
def atualizar_empresa():
    try:
        dados = request.json
        email = dados.get("email")
        nome = dados.get("nome")
        telefone = dados.get("telefone")

        sucesso = Bd_empresa.atualizar_dados_empresa(email, nome, telefone)

        if not sucesso:
            return jsonify({"sucesso": False, "message": "Empresa não encontrada"}), 404

        return jsonify({"sucesso": True, "message": "Dados atualizados com sucesso"})

    except Exception as e:
        return jsonify({"sucesso": False, "message": str(e)}), 500


# função para retornar todas as empresas exceto a logada
@app.route("/listarempresas", methods=["GET"])
def listar_empresas():
    try:
        email = request.args.get("email")
        empresas = Bd_empresa.listar_empresas(email)

        return jsonify({"sucesso": True, "empresas": empresas})
    except Exception as e:
        print("ERRO NO LISTAR_EMPRESAS:", e)
        return jsonify({"sucesso": False, "message": str(e)}), 500


# função para enviar o email recebido do suporte para o glimpse
@app.route("/suporte", methods=["POST"])
def suporte():
    dados = request.json
    mensagem = dados.get("mensagem")
    email_usuario = dados.get("email")

    try:
        email = EmailMessage()
        email["Subject"] = "Mensagem de Suporte - Glimpse"
        email["From"] = "bluehairdominhoie@gmail.com"
        email["To"] = "bluehairdominhoie@gmail.com"
        email.set_content(
            f"""Email do usuário: {email_usuario}
            Mensagem:
            {mensagem}
        """
        )

        # envia para o email
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login("bluehairdominhoie@gmail.com", "jshk xsmo mrkh uazf")
            smtp.send_message(email)

        return jsonify({"sucesso": True})

    except Exception as e:
        print("Erro no suporte:", e)
        return jsonify({"sucesso": False}), 500


# função para atualizar a foto de perfil
@app.route("/upload-foto", methods=["POST"])
def upload_foto():
    print("RECEBEU REQUISIÇÃO")

    foto = request.files["foto"]
    email = request.form["email"]

    hash_email = hashlib.md5(email.encode()).hexdigest()

    try:

        resultado = cloudinary.uploader.upload(
            foto,
            public_id=f"perfil/{hash_email}",
            overwrite=True,
            resource_type="image",
        )

        link = resultado["secure_url"]

        print("UPLOAD NA NUVEM OK:", link, flush=True)

        Bd_empresa.atualizar_foto(link, email)

        return jsonify({"status": "ok", "link": link})

    except Exception as e:
        print("ERRO NO UPLOAD:", e)
        return jsonify({"status": "erro", "mensagem": str(e)}), 500


# -------------------------------------------------------------

if __name__ == "__main__":
    app.run(debug=True)
