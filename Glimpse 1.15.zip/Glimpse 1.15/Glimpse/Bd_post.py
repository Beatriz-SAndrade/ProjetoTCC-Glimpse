import Bd_conexao as Bd_conexao
from datetime import datetime
import Bd_rede


# função para inserir um post no BD
def insert_post(link, data):
    print(" ")
    conexao = Bd_conexao.get_conexao()
    # extrai usuário a partir do link e busca o id da rede
    id_red = Bd_rede.get_idRede(extrair_usuario_instagram(link))

    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()
        # verifica se o post já existe
        if verifica_post(link):
            # Converte o ISO
            dt = datetime.fromisoformat(data.replace("Z", "+00:00"))
            data_mysql = dt.date()

            print("INSERINDO POST: ", link, " - ", data_mysql, " - ", id_red)
            cursor.execute(
                "Insert into social_db.post (link,data_post,id_red) values (%s,%s,%s)",
                (link, data_mysql, id_red),
            )
            r = conexao.commit()

        else:
            print("Ja inserido")
    print(" ")
    conexao.close()
    cursor.close()


# função para verificar se o post já existe
def verifica_post(link):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        print("Verificando existencia...")
        cursor.execute("Select 1 from social_db.post where link = %s limit 1;", (link))
        r = cursor.fetchone()
        print(r)
        conexao.close()
        cursor.close()

        # retorna true se não existe e false se já existe
        if r == None:
            resul = True
        else:
            resul = False

        return resul


# função para buscar o id do post pelo link
def read_idPost(link):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        print("LENDO ID A PARTIR DO LINK: ", link)
        cursor.execute("Select id_post from social_db.post where link= %s", (link,))
        r = cursor.fetchone()
        print(r[0])
        conexao.close()
        cursor.close()

        return r[0]


# função para descobrir o id da rede social de um post
def read_idRed(id_post):
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        print("LENDO ID A PARTIR DO CONTEUDO: ", id_post)
        cursor.execute("Select id_red from social_db.post where id_post= %s", (id_post))
        r = cursor.fetchone()
        print(r[0])
        conexao.close()
        cursor.close()

        return r[0]


# função para extrair apenas o nome de perfil de um link do instagram
def extrair_usuario_instagram(link):
    if not link:
        return None
    return (
        link.replace("https://", "")
        .replace("http://", "")
        .replace("www.", "")
        .replace("instagram.com/", "")
        .split("/")[0]
        .split("?")[0]
    )


# função para retornar todos os links dos posts coletados da rede
def get_linksPostByIdRede():
    conexao = Bd_conexao.get_conexao()
    if conexao:
        print("Conectado com sucesso!")
        cursor = conexao.cursor()

        print("LENDO ID A PARTIR DO CONTEUDO: ", Bd_rede.getIdRede())
        cursor.execute(
            "Select link from social_db.post where id_red= %s ", (Bd_rede.getIdRede())
        )
        r = cursor.fetchall()
        conexao.close()
        cursor.close()

        return r
