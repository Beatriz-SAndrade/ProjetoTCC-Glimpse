// inicializa o gráfico
const ctx = document.getElementById('sentimentosChart').getContext('2d');
// cria o gráfico de pizza
const chart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: ['Negativas', 'Neutras', 'Positivas'],
    datasets: [{
      data: [0, 0, 0],
      backgroundColor: ['#b71c1c', '#fbc02d', '#388e3c']
    }]
  }
});
// atualiza os sentimentos
atualizarGrafico();
console.log("Grafico carregado");

// função com a resposta do flask com os dados do BD
function carregarSentimentos() {
  fetch('http://localhost:5000/sentimentos')
    .then(res => res.json())
    .then(dados => {
      console.log(dados);

      chart.data.datasets[0].data = [
        dados.negativo,
        dados.neutro,
        dados.positivo
      ];

      chart.update();
    })
    .catch(err => console.error(err));
}

// função da barra lateral
async function abrirAba(tipo) {
  const aba = document.getElementById("abaLateral");
  const titulo = document.getElementById("tituloAba");
  const conteudo = document.getElementById("conteudoAba");

  titulo.innerText = tipo;

  let comentarios = [];

  if (filtro == 0) { //sem post selecionado
    comentarios = await imprimeComentsPorTipo(tipo);
  } else { // filtra por post específico
    comentarios = await imprimeComentsPorFiltro(tipo, filtro)
  }

  // transforma a resposta do flask em html
  conteudo.innerHTML = comentarios
    .map(c => `<p>${c}</p>`)
    .join("");

  aba.classList.add("aberta");
}

// fecha a aba lateral
function fecharAba() {
  document.getElementById("abaLateral").classList.remove("aberta");
}

// função para imprimir comentários pelo sentimento
async function imprimeComentsPorTipo(tipo) {
  try {
    const res = await fetch(
      `http://localhost:5000/pegaComentarioPorTipo?tipo=${tipo.toLowerCase()}`
    );
    const dados = await res.json();

    if (Array.isArray(dados)) {
      return dados;
    } else {
      console.error("Resposta inesperada:", dados);
      return [];
    }

  } catch (err) {
    console.error(err);
    return [];
  }
}

// função para imprimir comentários pelo sentimento e pelo post
async function imprimeComentsPorFiltro(tipo, idPost) {
  try {
    const res = await fetch(
      `http://localhost:5000/pegaComentarioPorFiltro?tipo=${tipo.toLowerCase()}&id_post=${idPost}`
    );
    const dados = await res.json();

    if (Array.isArray(dados)) {
      return dados;
    } else {
      console.error("Resposta inesperada:", dados);
      return [];
    }

  } catch (err) {
    console.error(err);
    return [];
  }
}

// função para atualizar o scraping
function iniciarScraping(modo) {
  if (modo == "leve") {
    caminho = "http://127.0.0.1:5000/scrapingleve"
  } else {
    caminho = "http://127.0.0.1:5000/scrapingcompleto"
  }
  fetch(caminho, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: localStorage.getItem("email"),
      modo: modo
    })
  })
    .then(res => res.json())
    .then(data => alert(data.message))
    .catch(() => alert("Erro ao iniciar scraping"));
}

// função para pegar os links dos posts
async function pegaLinks() {
  try {
    const res = await fetch("http://localhost:5000/pegaLinks");
    const dados = await res.json();

    if (Array.isArray(dados)) {
      return dados;
    } else {
      console.error("Resposta inesperada:", dados);
      return [];
    }

  } catch (err) {
    console.error(err);
    return [];
  }
}

// função para atualizar o gráfico por post
async function atualizarGrafico() {
  let url = "";

  if (filtro === 0) {
    url = "http://localhost:5000/sentimentos";
  } else {
    url = `http://localhost:5000/sentimentospost/${filtro}`;
  }

  try {
    const res = await fetch(url);
    const dados = await res.json();

    chart.data.datasets[0].data = [
      dados.negativo,
      dados.neutro,
      dados.positivo
    ];

    chart.update();
  } catch (err) {
    console.error("Erro ao atualizar gráfico:", err);
  }
}


// função para renderizar os links na lista
async function carregarPosts() {
  const posts = await pegaLinks();

  lista.innerHTML = "";

  posts.forEach(p => {
    lista.innerHTML += `
      <li>
        <label style="cursor:pointer">
          <input 
            type="checkbox"
            name="postSelecionado"
            onclick="selecionarPost(${p.id_post}, this)"
          >
          ${p.link}
        </label>
      </li>
    `;
  });
}

// lógica para selecionar o post para filtrar
function selecionarPost(id_post, checkbox) {
  const checkboxes = document.querySelectorAll(
    'input[name="postSelecionado"]'
  );
  if (!checkbox.checked) {
    filtro = 0;
    document.getElementById("conteudoAba").innerHTML = "";
    atualizarGrafico();
    return;
  }

  checkboxes.forEach(cb => {
    if (cb !== checkbox) cb.checked = false;
  });

  filtro = id_post;
  abrirAba("Todos");
  atualizarGrafico();
}

const lista = document.getElementById("listaPosts");
let filtro = 0;

carregarSentimentos();
console.log("Grafico carregado");

document.addEventListener("DOMContentLoaded", carregarPosts);